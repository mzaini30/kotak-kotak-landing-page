=== Nama Plugin ===
Contributors: Zen
Tags: landing_page, uno_css, tampilan
License: MIT

Plugin ini akan merapikan konten yang dimiliki dalam bentuk kotak-kotak dengan dua kolom

== Contoh Jadinya ==

![Contoh plugin Kotak-Kotak Landling Page](https://user-images.githubusercontent.com/7939342/234778510-1bc6b728-5816-44d6-9da3-b777201d2306.png)

== Cara Pakai ==

```html
[kotak_kotak]

[kotak judul="Pertama"]
Ini konten pertama
[/kotak]

[kotak judul="Kedua"]
Ini konten kedua
[/kotak]

[/kotak_kotak]
```